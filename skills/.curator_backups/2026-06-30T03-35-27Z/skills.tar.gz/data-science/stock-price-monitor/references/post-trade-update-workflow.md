# 清仓后6步更新工作流

> 2026-06-30 制定：用户要求买卖交易必须推送到企微，且清仓后更新所有配置。

## ⚠️ 触发时机
用户说出以下任何一句时，执行本流程：
- "清仓了XX"
- "卖出了XX"
- "按照XX价卖了XX"
- "涨停价清仓了XX"

## 完整6步清单（按顺序，不能跳过）

### 第1步：获取实时价格验证交易
```python
import urllib.request, json, os
os.environ['NO_PROXY'] = '*'

code = "0.002167"  # 东财secid
url = f"http://push2delay.eastmoney.com/api/qt/stock/get?secid={code}&fltt=2&fields=f43,f170,f60"
req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
data = json.loads(urllib.request.urlopen(req, timeout=10).read())['data']
price = data['f43']
change_pct = data['f170']

# 计算盈亏
cost = 21.247  # 成本价
shares = 300
profit = (price - cost) * shares
profit_pct = (price - cost) / cost * 100

new_total = TOTAL_CAPITAL + int(round(profit))
```

### 第2步：更新 price_monitor.py
```python
# 1. STOCKS: cost=None, shares=0, buy_date=None, type="观察"
# 2. 注释加入清仓日期+盈亏
# 3. TOTAL_CAPITAL += 盈利
```
位置: `/home/jmy/.hermes/profiles/eastmoney-bot/scripts/price_monitor.py`

### 第3步：清理 .monitor_state.json
```python
import json
state_file = '/home/jmy/.hermes/profiles/eastmoney-bot/.monitor_state.json'
with open(state_file) as f:
    state = json.load(f)

code = "002167"

# 清除涨停状态
if 'prev_limit_up' in state:
    state['prev_limit_up'][code] = False

# 清除止损止盈相关alert
if code in state.get('alerted', {}):
    remove_keys = ['sl', 'near_sl', 'near_tp', 'tp', 'near_limit_up']
    state['alerted'][code] = [a for a in state['alerted'][code] if a not in remove_keys]

# ⚠️ 写入交易通知到pending_trades
msg = f"""🔴 【东方锆业 {code} 清仓】

📊 交易详情
━━━━━━━━━━━━━━━━━━━━
买入: {shares}股 × {cost} = {cost*shares:.0f}元
卖出: {shares}股 × {price} = {price*shares:.0f}元
盈利: {profit:+.0f}元（{profit_pct:+.1f}%）
━━━━━━━━━━━━━━━━━━━━
💰 总资金: {new_total}元
📊 累计盈利: +{new_total-30000}元"""

state.setdefault('pending_trades', []).append({"msg": msg})

with open(state_file, 'w') as f:
    json.dump(state, f, ensure_ascii=False)
```

### 第4步：更新 docs/system-logic.md
内容更新：
- 交易记录表：新增一行
- 合计：更新累计盈利
- 持仓表：移除该股或移到观察
- 资金状态：总资金、持仓市值、可用资金

### 第5步：语法验证
```bash
python3 -c "import ast; ast.parse(open('/home/jmy/.hermes/profiles/eastmoney-bot/scripts/price_monitor.py').read())"
```

### 第6步：Git提交推送
```bash
cd /home/jmy/.hermes/profiles/eastmoney-bot
git add scripts/price_monitor.py docs/system-logic.md .monitor_state.json
git commit -m "交易: {股票名} {操作} {盈亏} — 改为观察，总资金{new_total}"
git push
```

## ⚠️ 买入后更新流程

用户买入后，执行类似流程但方向相反：
1. 更新STOCKS: cost=买入价, shares=买入股数, buy_date=今日, type="持仓"
2. 清理该股票alert状态（去掉历史观察信号）
3. 写入买入通知到pending_trades
4. 更新docs/system-logic.md
5. 语法验证 + Git提交
