---
name: stock-price-monitor
description: 股票价格实时监控 + 企业微信/Telegram推送
related_skills:
  - scanner-trading-plan
triggers:
  - 股票监控
  - 价格预警
  - 止盈止损
  - 企业微信推送
  - 盘中提醒
---

# 股票价格监控系统

## 功能
- 🔔 开盘播报 (9:30)
- ⏰ 整点播报 (每小时)
- ⚡ 涨跌提醒 (超2%)
- 🎯 止盈止损触发提醒
- 📊 收盘总结 (15:00)

## 技术方案

### 脚本位置
`~/.hermes/profiles/eastmoney-bot/scripts/price_monitor.py`

### 调度方式
- Cronjob定时任务，每5分钟运行
- `no_agent=True` 模式，脚本直接执行不走LLM
- 交易日 9:00-15:00 运行

### 推送通道
1. **企业微信群机器人** (主要)
   - Webhook: `https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=xxx`
   - POST JSON: `{"msgtype":"text","text":{"content":"消息内容"}}`
   - 返回: `{"errcode":0,"errmsg":"ok"}` 表示成功

2. **Telegram** (备用)
   - 通过cronjob的deliver机制推送

### 数据源
```python
# 东财实时行情API
url = f"http://push2delay.eastmoney.com/api/qt/stock/get?secid={secid}&fields=f43,f170,f44,f45,f46,f60"
# secid格式: 0.002972 (深市) 1.600000 (沪市)
# f43=现价(/100) f170=涨跌幅(/100) f44=最高 f45=最低 f46=开盘 f60=昨收
```

### 状态管理
- 状态文件: `.monitor_state.json`
- 避免重复提醒: 记录已触发的alerted_types
- 每天9:30自动重置状态

## 操作步骤

### 新建监控
1. 修改脚本中的股票配置:
```python
STOCK_CODE = "0.002972"  # 东财secid
STOCK_NAME = "科安达"
AVG_COST = 16.443        # 持仓均价
SHARES = 400             # 持仓数量
TAKE_PROFIT = 18.91      # 止盈价 (+15%)
STOP_LOSS = 15.13        # 止损价 (-8%)
```

2. 创建cronjob:
```
schedule: "*/5 9-15 * * 1-5"
no_agent: True
script: price_monitor.py
```

3. 测试推送:
```bash
curl -s -X POST "https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=xxx" \
  -H "Content-Type: application/json" \
  -d '{"msgtype":"text","text":{"content":"测试消息"}}'
```

### 修改参数
- 止盈止损: 修改脚本中的 TAKE_PROFIT / STOP_LOSS
- 涨跌阈值: 修改 CHANGE_THRESHOLD (默认2%)
- 推送频率: 修改cronjob的schedule

### 停止监控
```bash
hermes cron list  # 找到job_id
hermes cron remove <job_id>
```

## 推送规则设计

**⚠️ 用户偏好：推送要频繁，不要只推触发条件**

完整推送规则：
| 类型 | 频率 | 说明 |
|------|------|------|
| 🔔 开盘播报 | 9:30 | 开盘价+持仓状态 |
| ⏰ 整点播报 | 每小时 | 当前价格+盈亏 |
| ⚡ 涨跌提醒 | 超2% | 快速拉升/跳水 |
| 🎯 止盈止损 | 触发 | 关键价位提醒 |
| 📊 收盘总结 | 15:00 | 当日盈亏总结 |

**错误做法**：只推触发条件（止盈止损），用户觉得太少
**正确做法**：定时汇报+涨跌播报+开盘收盘全加

## 注意事项
- 非交易时间不推送（周末、节假日）
- 状态文件每天自动重置
- 企业微信webhook有频率限制（每分钟20条）
- 价格数据来自东财push2delay，有几分钟延迟

## 交易记录
监控脚本备份在交易计划仓库: https://github.com/bwadasd123/stock-trading-plan

## 扩展
- 多股票监控: 复制脚本改STOCK_CODE，创建多个cronjob
- 推送到钉钉: 改webhook地址和消息格式
- 增加技术指标: 调用K线API计算RSI/MACD
