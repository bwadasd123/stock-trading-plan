# 全屏水印实现

## CSS方案

使用 flexbox 布局 + JS 动态生成，实现水印铺满屏幕。

### CSS样式

```css
.watermark-overlay {
  position: fixed;
  top: 0; left: 0;
  width: 100%; height: 100%;
  pointer-events: none;  /* 不影响点击 */
  z-index: 9999;
  display: flex;
  flex-wrap: wrap;
  align-content: flex-start;
}
.watermark-item {
  width: 300px;
  height: 150px;
  display: flex;
  align-items: center;
  justify-content: center;
  transform: rotate(-35deg);
  flex-shrink: 0;
}
.watermark-item span {
  font-size: 16px;
  color: rgba(30, 64, 175, 0.1);  /* 半透明蓝色 */
  font-weight: 600;
  white-space: nowrap;
  letter-spacing: 2px;
  user-select: none;
}
```

### JavaScript动态生成

```javascript
function generateWatermarks() {
  const overlay = document.getElementById('watermark');
  const text = '水印文字';
  const itemWidth = 300;
  const itemHeight = 150;
  
  const cols = Math.ceil(window.innerWidth / itemWidth) + 2;
  const rows = Math.ceil(window.innerHeight / itemHeight) + 2;
  const total = cols * rows;
  
  let html = '';
  for (let i = 0; i < total; i++) {
    html += `<div class="watermark-item"><span>${text}</span></div>`;
  }
  overlay.innerHTML = html;
}
generateWatermarks();
window.addEventListener('resize', generateWatermarks);
```

### HTML

```html
<div class="watermark-overlay" id="watermark"></div>
```

## 要点

- `pointer-events: none` 确保不影响页面交互
- `user-select: none` 防止选中水印文字
- 窗口 resize 时重新生成水印
- 透明度 0.1 适中，不影响内容阅读
