---
name: stock-screener-web
description: Extend and maintain the A股智能筛选 Web Dashboard (Flask + MySQL + 东方财富API). Add features, database tables, API endpoints, and frontend functionality.
tags: [stock, flask, mysql, eastmoney, web-dashboard, a股, screener]
triggers:
  - stock screener feature request
  - stock_web_v2.py modification
  - A股看板功能
  - add API endpoint to stock dashboard
  - stock database table
  - 板块资金流向
  - sector flow
  - 启动A股系统
  - 启动系统
  - start stock screener
  - A股系统启动
  - 启动A股
  - stock_screener startup
  - app.py startup
---

# A股智能筛选 Web Dashboard

## Overview

Flask-based web dashboard for A-share stock screening with:
- Full market scanning (东方财富API)
- Two-round filtering: fundamentals + technical indicators
- MySQL storage for results and snapshots
- SSE real-time progress
- Proxy pool management (anti-crawl)
- **板块资金流向** (Sector Fund Flow) - Industry & Concept sectors, with ECharts history trend charts
- **LOF/ETF套利监控** - Integrated into main dashboard nav (was standalone page)
- **龙虎榜** (Dragon Tiger List)
- **自选股监控** (Watchlist)
- **Dark/Light mode** - Full theme support with CSS variables

## Key References
- `references/proxy-pool-management.md` - **⚠️ 代理池管理 + 407降级 + push2his端点**
- `references/kline-indicator-pitfalls.md` - **⚠️ K线数据与指标计算陷阱**（smplmt问题、量比计算、RSI方式）
- `references/historical-record-cleanup.md` - 历史扫描记录清理 + de3.py完整指标公式参考
- `references/report_page.md` - 市场日报页面设计规范（含亮暗主题切换）
- `references/arbitrage_monitor.md` - LOF/ETF套利监控（含持仓计算系统）
- `references/version-filter-pattern.md` - 版本筛选UI模式（下拉框+表格标签+API参数）
- `references/frontend-tab-pattern.md` - Tab navigation + standalone page integration
- `references/dark-mode-pattern.md` - Dark/Light mode CSS pattern
- `references/echarts-modal-pattern.md` - Reusable ECharts modal overlay pattern
- `references/health-check.md` - Endpoint health check commands
- `references/eastmoney-api-endpoints.md` - **东财API端点诊断**（502错误排查、域名用途）
- `references/eastmoney-domain-routing.md` - **⚠️ 东财域名路由规则**（push2delay vs push2his vs push2）
- `references/post-scan-workflow.md` - **扫描结果解读 + 投资决策流程**（仓位管理、止损止盈、信号验证）

## Health Check & Diagnostics

See `references/health-check.md` for full endpoint test commands, component checks, and known issues.

**Quick check after startup:**
```bash
curl -s -o /dev/null -w "%{http_code}" http://localhost:8080/  # Should be 200
```

**All endpoints healthy** as of 2026-06-08 — run full health check from `references/health-check.md` after any changes.

## ETF Price Scaling
For ETFs (513100 etc), use `fltt=1` and divide by **1000** (not 100). See `references/etf-price-scaling.md`.

## Chart Generation
Dark-themed matplotlib charts for Telegram. Color palette matches style.css. See `references/chart-template-dark.md`.

## Related Skills

- **serenity-chokepoint-investing** (research/) — AI supply-chain bottleneck analysis framework. Installed from GitHub `leospark/serenity-chokepoint-investing-skills`. Use for individual stock analysis, not ETFs.

## Related Components

### 板块资金流向视频 (flow_douyin.py)
Douyin-format race chart video generator. See MEMORY.md for details.

### 市场日报 (/report)
Daily market report page. See `references/report_page.md` for design spec.

### LOF/ETF套利监控 (/arbitrage)
Real-time LOF/ETF premium monitoring with holdings-based NAV calculation.
See `references/arbitrage_monitor.md` for full documentation.

### 双版本对比扫描 (/dual_scan)
Compare old version (smplmt=460 sampling) vs new version (daily K-line) scanning logic.
See `references/kline-indicator-pitfalls.md` for details.
See `references/dual-scan-version-filter.md` for history page version filtering.

**优化版（2026-06-10）**：只获取一次市场列表，每只股票连续拉两次K线（老smplmt + 新日线），时间省一半。

**任务历史记录**：双版本扫描会写两条 `scan_task_history`（`_old` 和 `_new`），包含开始/完成/异常状态。

**Storage**: Results stored in `stock_scan_results` table, distinguished by `scan_id` suffix:
- Old version: `scan_id` ends with `_old` (e.g. `20260609_143025_old`)
- New version: `scan_id` ends with `_new` (e.g. `20260609_143025_new`)

**History page filtering**: Version dropdown in history signals page filters by scan_id pattern:
- `version=old` → `scan_id LIKE '%_old'`
- `version=new` → `scan_id LIKE '%_new'`
- `version=normal` → `scan_id NOT LIKE '%_old' AND scan_id NOT LIKE '%_new'`

**Table display**: Version column shows colored badges (orange=old, blue=new) based on scan_id suffix.

## Quick Start
```bash
cd /home/jmy/stock-screener
/home/jmy/.hermes/hermes-agent/venv/bin/python app.py  # Starts on port 8080
# Verify: ss -tlnp | grep 8080
```

## ⚠️ Browser Cache Pitfall
After ANY code change (JS/CSS/HTML), the browser may cache old files. **User won't see changes even if Flask loaded the new code.**
- **Verify Flask loaded new code**: `curl -s http://localhost:8080/static/js/app.js | grep "new_feature"`
- **Fix**: Tell user to **hard refresh** (Ctrl+F5 / Cmd+Shift+R), or open DevTools (F12) → Network → check "Disable cache"
- **Don't** assume Flask needs restarting if the backend is already running with new code

**⚠️ Pitfall**: The uv Python 3.11 (`/home/jmy/.local/share/uv/python/cpython-3.11.15-linux-x86_64-gnu/bin/python3.11`) does NOT have flask installed — only pip/setuptools. Use the hermes-agent venv python (`/home/jmy/.hermes/hermes-agent/venv/bin/python`) which has all dependencies (flask, pymysql, requests, numpy). The system python3.12 lacks MySQLdb. **Always use the venv python for starting the app.**

## Architecture
```
app.py                    # Flask main entry + blueprint registration
config.py                 # Configuration
anti_crawl.py             # Proxy pool + cookie management
models/
  database.py             # MySQL connection + table init
services/
  scanner.py              # Stock scanning logic
  sector_flow.py          # Sector fund flow analysis
  kline.py                # K-line data
  dragon_tiger.py         # Dragon tiger list
  daily_digest.py         # Daily digest generation
  watchlist.py            # Watchlist management
  arbitrage_targets.py    # LOF/ETF arbitrage targets
  fund_holdings.py        # Fund holdings mapping (NEW)
  asset_prices.py         # Asset price fetching (NEW)
  nav_calculator.py       # NAV calculator (NEW)
  scanner_dual.py         # Dual version comparison scanning (NEW)
api/
  scan.py                 # Scanner API
  sector.py               # Sector flow API
  report.py               # Report API
  arbitrage.py            # Arbitrage API
  dual_scan.py            # Dual version comparison API (NEW)
  ...
templates/
  index.html              # Main dashboard (all pages integrated)
  arbitrage.html          # Standalone arbitrage page (legacy, main is in index.html)
  report.html             # Report page
static/
  css/
    style.css             # All styles (dark/light theme, ~1820 lines)
    dual_scan.css         # Dual version comparison page styles (NEW)
  js/
    app.js                # Main app logic, tab system, theme toggle
    scanner.js            # Market scanner
    sector.js             # Sector fund flow + history charts
    dragon.js             # Dragon tiger list
    watchlist.js          # Watchlist
    arbitrage.js          # LOF/ETF arbitrage monitoring
    daily.js              # Daily digest
    dual_scan.js          # Dual version comparison page (NEW)
```

## Database
MySQL with tables for:
- `scan_results` - Stock scan results
- `sector_flow` - Sector fund flow data
- `watchlist` - User watchlist
- `daily_snapshots` - Daily snapshots

## Development Rules
1. **After ANY code change**: Restart Flask immediately — see `references/flask_restart.md` for reliable restart pattern (kill by port, verify port free, start with background=true)
2. **After ANY code change**: Update README.md (功能列表、项目结构、API文档、使用指南), then git commit + push together. User explicitly requires this (2026-06-08).
3. **代理池 secret/orderId**: 代码里 `***` 是故意混淆，不是失效。用户自行维护，永远不要质疑订单号是否有效或建议更换。如果代理池为空，只报告"代理池为空"，不要分析secret/orderId问题。
3. **Use `safe_get`** for all eastmoney API calls (proxy pool rotation). If proxies return 407, safe_get auto-falls back to direct connect.
4. **⚠️ 东财域名路由规则（2026-06-10确认）**：
   - `push2delay.eastmoney.com`: 股票列表(clist/get)、个股详情(stock/get) — 直连和代理都可用
   - `push2delay.eastmoney.com`: **K线数据(kline/get)返回空！** dktotal=0, klines=[]，不能用于K线！
   - `push2his.eastmoney.com`: **K线数据(kline/get) — 仅代理可用**，直连被拒绝
   - `push2his.eastmoney.com`: 股票列表(clist/get) — 代理可用
   - `push2.eastmoney.com`: 连接被拒绝（直连和代理都失败）
   - **结论**: clist用push2delay直连，kline用push2his+代理。详见`references/eastmoney-domain-routing.md`
5. **Use `get_sector_headers()`** for proper headers
6. **`push2.eastmoney.com` can return 502** — fallback to `push2his.eastmoney.com` (same API paths, works with direct HTTP). See `references/proxy-pitfalls.md`.
7. **代理407降级** — `safe_get` should fall back to direct connection on proxy 407 errors. See `references/proxy-pitfalls.md`.
5. **Cache aggressively** - 60s TTL for API responses
6. **Mobile-first** - Responsive design for all pages
7. **After startup, run health check** — verify all endpoints return expected codes (see `references/health-check.md`)
8. **All API endpoints need try/except** — Wrap handler body in `try/except Exception as e: logger.error(...); return jsonify({"error": str(e)}), 500`. Prevents 500 errors when data is valid but an unexpected exception occurs.
9. **Browser cache** — 用户看不到代码变化时，先curl验证Flask已加载新代码，再让用户Ctrl+F5强制刷新。
10. **Python Global Variable Pitfall** — `from module import var` creates local binding. When module reassigns `var`, importing module still has OLD reference. Use `import module as m` + `m.var` for shared mutable state. Critical for SCAN_STATE in scanner.
11. **K线API** — 禁用smplmt参数(返回采样数据)! 量比=今日/昨日。RSI用SMA(与通达信差~6点)。
12. **push2返回502时** — 批量替换所有.py文件: `find . -name "*.py" -exec sed -i 's|push2\.eastmoney\.com|push2his.eastmoney.com|g' {} \;` 注意sector_flow.py里的HTTPSConnection格式也要改。
9. **Dark mode CSS pattern** — Use CSS variables (`var(--bg-primary)`, etc.) for all colors. Add `[data-theme="light"]` overrides for any component with hardcoded backgrounds/borders.
10. **K线数据获取** — 不能使用 `smplmt` 参数！否则返回采样数据（约20天一根），导致指标计算全部错误。详见 `references/kline-indicator-pitfalls.md`。
11. **量比计算** — 跟随 de3.py 逻辑，使用 "今日/昨日"（`v.iloc[-1] / v.iloc[-2]`），不是标准的"今日/5日均量"。用户明确要求不要修改。详见 `references/kline-indicator-pitfalls.md`。
12. **双版本对比系统** — 用于对比老版本（smplmt=460）和新版本（日线）的扫描结果。详见 `references/kline-indicator-pitfalls.md`。
13. **东财API限流** — 批量请求时需要添加延迟（0.5-1秒），否则会被限流。详见 `references/kline-indicator-pitfalls.md`。
14. **Python全局变量陷阱** — 跨模块访问可变全局变量时，必须用 `import module as m` + `m.var` 方式，不能用 `from module import var`（后者创建本地绑定，模块重新赋值后不会同步）。详见 `references/kline-indicator-pitfalls.md`。
15. **代理池为空时的诊断** — 如果扫描返回0只股票，先检查代理池状态（`/api/proxy_status`）。代理池为空 + 直连被限流 = push2.eastmoney.com 返回 502。代码里 `***` 是故意混淆，不是配置错误。详见 `references/dual-scan-version-filter.md`。
16. **东财502诊断** — 当扫描返回0只股票时，先检查 `push2.eastmoney.com` 是否返回502。测试方法：`curl -s -o /dev/null -w "%{http_code}" "http://push2.eastmoney.com/api/qt/clist/get?pn=1&pz=1"`。如果返回502，但 `push2his` 正常，则是东财服务器问题，需等待恢复。详见 `references/eastmoney-api-endpoints.md`。
17. **代理池启动延迟** — 代理池在Flask启动时异步初始化（daemon thread），需要几秒填充。刚启动就请求K线数据会超时。测试API前等待3-5秒。
18. **任务历史记录finally块** — `save_task_end` 必须放在 `finally` 块中，确保扫描完成/异常/被kill都能更新状态。否则Flask进程被重启后任务永远停在 `running`。详见 `references/task-tracking-pattern.md`。
19. **⚠️ 超时任务自动清理** — 即使用了 `finally` 块，外部kill（SIGKILL/OOM/部署）仍会导致任务卡在 `running`。每次启动新扫描前必须调用 `_cleanup_stale_tasks()` 清理超过30分钟的 running 任务。详见 `references/task-tracking-pattern.md`。
19. **K线请求超时** — K线接口通过代理访问push2his，单次请求可能需要5-15秒。API端点的timeout应设为30秒以上，前端等待超时设为60秒。
20. **双版本扫描filter参数陷阱** — 手动触发 `/api/dual_scan_all` 时必须传完整的filter参数（r1_turnover, r1_cap_max, r2_rsi, r2_macd, r2_cci, r2_ma20, r2_vol_ratio, r2_turnover）。只传r1_参数时第二轮筛选条件全为默认值(0/False)，等于不过滤，会返回大量不符合条件的股票。前端会自动传所有条件，但代码测试时容易遗漏。
21. **代理池只用宜代理API** — 用户明确要求不用本地代理(172.25.176.1:2080)，只用宜代理API返回的代理IP。`anti_crawl.py`中的`PROXY_CONFIG`配置宜代理API地址。

## Adding a New Page to the Dashboard

When integrating a new feature page (e.g. LOF套利), follow this exact sequence:

1. **`static/js/app.js`** — Add entry to `TAB_CONFIG` object:
   ```js
   newpage: { icon: '💹', title: '页面标题', refreshable: true }
   ```
   Add case to `loadTabData()` switch:
   ```js
   case 'newpage': loadNewPage(); break;
   ```

2. **`templates/index.html`** — Add sidebar nav item:
   ```html
   <a href="#" class="nav-item" data-page="newpage">
     <span class="nav-icon">💹</span>
     <span class="nav-text">页面标题</span>
   </a>
   ```
   Add page container in `.page-container`:
   ```html
   <div id="page-newpage" class="page">
     <div id="newpage-result"></div>
   </div>
   ```
   Add `<script src="/static/js/newpage.js"></script>` before `</body>`.

3. **`static/js/newpage.js`** — Create JS module with `loadNewPage()` function.

4. **`static/css/style.css`** — Add component styles. Use CSS variables for dark/light theme compatibility.

5. **Restart Flask + update README.md + git commit + push.**
   - README更新检查清单（3处）：
     1. **功能概览表格** — 添加新功能行
     2. **项目结构** — 添加新文件到目录树
     3. **使用文档** — 添加功能详细说明章节
   - Git推送：如果 `git push` 被拒绝（remote有新提交），先 `git pull --rebase origin master` 再 push

See `references/frontend-tab-pattern.md` for the full pattern with examples.
