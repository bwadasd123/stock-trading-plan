# System Settings Page Pattern

## Overview

The settings page provides a UI for configuring system parameters (proxy, database, scan settings). It uses a card-based layout with info display and form inputs.

## HTML Structure

```html
<div id="page-settings" class="page">
  <div class="settings-container">
    <div class="settings-section">
      <h3>🔗 代理设置</h3>
      <div class="settings-card">
        <div class="settings-info">
          <div class="info-row">
            <span class="label">当前代理:</span>
            <span id="proxy_current" class="value">加载中...</span>
          </div>
        </div>
        <div class="settings-form">
          <div class="form-row">
            <label>Secret:</label>
            <input type="text" id="proxy_secret" class="input">
          </div>
          <div class="form-actions">
            <button class="btn btn-primary" onclick="saveConfig()">💾 保存</button>
          </div>
          <div id="msg" class="msg-area"></div>
        </div>
      </div>
    </div>
  </div>
</div>
```

## CSS

```css
.settings-container { max-width: 800px; }
.settings-section { margin-bottom: 24px; }
.settings-card { background: var(--bg-secondary); border: 1px solid var(--border-color); border-radius: 8px; padding: 20px; }
.info-row { display: flex; margin-bottom: 8px; }
.info-row .label { width: 120px; color: var(--text-secondary); }
.form-row { display: flex; align-items: center; margin-bottom: 12px; gap: 12px; }
.form-row label { width: 80px; }
.form-row .input { flex: 1; }
.form-actions { display: flex; gap: 8px; margin-top: 16px; }
.msg-area { margin-top: 12px; font-size: 13px; }
```

## Tab Integration

Add to TAB_CONFIG: `settings: { icon: '⚙️', title: '系统设置', refreshable: false }`
