# 东财API域名路由规则（2026-06-10确认）

## 域名用途矩阵

| API路径 | push2delay (直连) | push2delay (代理) | push2his (直连) | push2his (代理) |
|---------|-------------------|-------------------|-----------------|-----------------|
| `/api/qt/clist/get` (股票列表) | ✅ | ✅ | ❌ 拒绝 | ✅ |
| `/api/qt/stock/get` (个股详情) | ✅ | ✅ | ❌ 拒绝 | ✅ |
| `/api/qt/stock/kline/get` (K线) | ❌ 空数据 | ❌ 空数据 | ❌ 拒绝 | ✅ |
| `/api/qt/ulist.np/get` (ETF列表) | ✅ | ✅ | ❌ 拒绝 | ✅ |
| `/api/qt/kamt.rtmin/get` (北向资金) | ✅ | ✅ | ❌ 拒绝 | ✅ |

## 关键发现

### push2delay 的 K线接口返回空数据
```
GET http://push2delay.eastmoney.com/api/qt/stock/kline/get?secid=1.600519&klt=101&lmt=250
→ {"rc":0, "data":{"code":"600519","name":"贵州茅台","dktotal":0,"klines":[]}}
```
- `dktotal: 0` 表示没有K线数据
- 这是东财服务端行为，不是客户端问题
- 即使加 `beg`、`cb`、不同 `ut` 参数也返回空

### push2his 必须通过代理
- 直连 `push2his` → `RemoteDisconnected('Remote end closed connection without response')`
- 代理访问 `push2his` → 正常返回完整K线数据（5000+条）

### push2 完全不可用
- 直连 → 连接被拒绝
- 代理 → 连接被拒绝
- 曾经返回502，现在直接拒绝

## 代码配置

### K线接口（kline.py, scanner_dual.py）
```python
# ✅ 正确：push2his + 代理
url = "http://push2his.eastmoney.com/api/qt/stock/kline/get"
resp = safe_get(url, headers=headers, params=params, timeout=10)  # 走代理

# ❌ 错误：push2delay的K线返回空
url = "http://push2delay.eastmoney.com/api/qt/stock/kline/get"
```

### 股票列表接口（scanner.py, sector_flow.py）
```python
# ✅ 正确：push2delay 直连
url = "http://push2delay.eastmoney.com/api/qt/clist/get"
resp = safe_get(url, headers=headers, params=params, timeout=15)  # 代理或直连都行
```

### 个股详情接口（api/scan.py, asset_prices.py）
```python
# ✅ 正确：push2delay 直连
url = "http://push2delay.eastmoney.com/api/qt/stock/get"
```

## 诊断命令

```bash
# 测试push2delay股票列表
curl -s "http://push2delay.eastmoney.com/api/qt/clist/get?pn=1&pz=1" | python3 -c "import sys,json; d=json.load(sys.stdin); print(f'total={d[\"data\"][\"total\"]}')"

# 测试push2delay K线（预期空）
curl -s "http://push2delay.eastmoney.com/api/qt/stock/kline/get?secid=1.600519&klt=101&lmt=10" | python3 -c "import sys,json; d=json.load(sys.stdin); print(f'klines={len(d[\"data\"][\"klines\"])}')"

# 测试push2his K线（需代理）
# 见 proxy-pool-management.md 的代理获取方法
```

## 历史变更
- 2026-06-08: 发现push2返回502，改为push2his
- 2026-06-10: push2his直连也失败，发现push2delay可直连（但K线返回空）
- 2026-06-10: 确认push2his K线必须走代理，push2delay K线永远返回空
