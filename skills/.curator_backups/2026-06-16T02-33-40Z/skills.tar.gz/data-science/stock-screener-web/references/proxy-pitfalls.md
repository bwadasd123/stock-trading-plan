# Proxy & Network Pitfalls

## Proxy Pool Blocking Startup (CRITICAL)
`anti_crawl.py` `ProxyPool.__init__` calls `_fill_on_init()` synchronously. When proxy API key is expired (ydaili.cn), each `get_proxy_from_api()` retries 3× with 8s timeout + 2s sleep = 30s/attempt × 10 attempts = **up to 5 minutes blocking**.

**Fix**: Make non-blocking:
```python
# In ProxyPool.__init__:
threading.Thread(target=self._fill_on_init, daemon=True).start()
```

**Also**: `safe_get()` calls `get_proxy_dict()` → `PROXY_POOL.get()` → `_refill(2)` if empty. Every `safe_get` can block ~60s if proxy API is down.

## eastmoney API Endpoint Fallback (CRITICAL)
**`push2.eastmoney.com` can return 502 (nginx Bad Gateway).** When this happens, ALL stock list and sector flow requests fail — scanner gets 0 stocks, sector flow empty.

**Fallback**: Use `push2his.eastmoney.com` instead. Same API paths work on both hosts:
- `/api/qt/clist/get` — stock list (used by scanner, sector flow)
- `/api/qt/stock/get` — individual stock data
- `/api/qt/stock/kline/get` — K-line data (this was always on push2his)

**Important**: `push2his` works with **direct HTTP** (no proxy needed in WSL). `push2` also returns 502 on direct connection. So when push2 is down, proxy won't help — must switch to push2his.

**Migration**: Use `sed` to batch-replace across all .py files:
```bash
find . -name "*.py" -exec sed -i 's|push2\.eastmoney\.com|push2his.eastmoney.com|g' {} \;
```
Watch for `http.client.HTTPSConnection("push2.eastmoney.com")` in sector_flow.py — needs separate sed since it's not a URL format.

## Proxy 407 Authentication Failure → Direct Fallback
Proxy pool returns IPs that require authentication (407 Proxy Authentication Required). This means the ydaili proxy type may not match the expected format.

**Fix in `safe_get()`**: When HTTP 407 received, mark proxy as bad and fall back to direct connection:
```python
elif resp.status_code == 407:
    logger.warning(f"⚠️ 代理认证失败(407)，降级到直连")
    if proxy_str:
        PROXY_POOL.mark_bad(proxy_str)
        proxy_str = None
    use_proxies = {}
    PROXY_STATUS["current"] = "本地直连"
    continue
```

## Proxy Pool Blocking Startup (CRITICAL)
`calculateScore()` in scanner.js:
```javascript
if (circCap && circCap <= 200)  // circCap=0 is falsy → fails!
```
When proxy fails, `circ_cap` defaults to 0, and JavaScript treats 0 as falsy. Shows "不通过" for 流通市值 check even though stock passes.

**Root fix**: Make the API call work (use proxy). **Frontend fix** (defensive): `if (circCap > 0 && circCap <= 200)`.

## api/scan.py Import Pitfall
When modifying `/api/analyze`, ensure these imports exist at top of `api/scan.py`:
```python
import re
import logging
logger = logging.getLogger(__name__)
```
The old code used local `import re as _re` and `import requests as _req` which were removed during cleanup. Without the top-level imports, you get `NameError: name 're' is not defined` → 500 error.

## Proxy API Key Renewal
- Provider: ydaili.cn
- Config: `anti_crawl.py` → `PROXY_CONFIG["PROXY_GET_URL"]`
- When expired: proxy pool empties → all eastmoney requests fail → circ_cap=0, scanner hangs
- Renewal: regenerate from ydaili.cn dashboard, update the URL
