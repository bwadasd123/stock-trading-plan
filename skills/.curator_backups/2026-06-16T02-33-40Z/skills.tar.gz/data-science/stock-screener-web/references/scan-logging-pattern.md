# Scan Logging Pattern for User Verification

When user suspects scan calculations are wrong, add detailed foreground logs showing per-stock analysis.

## User Feedback

"我希望你再扫描的时候把日志过程放在前台可以吗？比对计算过程，我现在总感觉你计算的都不对"

## Implementation

### Round 1: Log filtered-out stocks with reasons

```python
# In services/scanner.py, Round 1 filter section
filtered_out = []
for s in stocks:
    ok = True
    reasons = []
    
    # 涨幅 > 0
    if filters.get("r1_change_gt0") and s["change_pct"] <= 0:
        ok = False
        reasons.append(f"涨幅{s['change_pct']:.2f}%≤0")
    
    # 换手率 > 阈值（只有当值 > 0 时才生效）
    turnover_min = filters.get("r1_turnover", 0)
    if turnover_min > 0 and s["turnover"] < turnover_min:
        ok = False
        reasons.append(f"换手率{s['turnover']:.2f}%<{turnover_min}%")
    
    # 成交额 > 阈值
    amount_min = filters.get("r1_amount", 0)
    if amount_min > 0 and s["amount"] < amount_min * 1e8:
        ok = False
        reasons.append(f"成交额{s['amount']/1e8:.2f}亿<{amount_min}亿")
    
    # PE > 0
    if filters.get("r1_pe_gt0") and s["pe"] <= 0:
        ok = False
        reasons.append(f"PE={s['pe']:.2f}≤0")
    
    # 流通市值 ≤ 阈值
    cap_max = filters.get("r1_cap_max", 9999)
    if cap_max < 9999 and s["circ_cap"] > cap_max:
        ok = False
        reasons.append(f"市值{s['circ_cap']:.2f}亿>{cap_max}亿")
    
    if ok:
        round1.append(s)
    else:
        filtered_out.append(f"{s['name']}({s['code']}): {', '.join(reasons)}")

logger.info(f"  第一轮筛选: {len(stocks)} → {len(round1)}只")
if filtered_out:
    for msg in filtered_out[:5]:
        logger.info(f"    ❌ {msg}")
    if len(filtered_out) > 5:
        logger.info(f"    ... 还有 {len(filtered_out) - 5} 只被过滤")
```

### Round 2: Log pass/fail with indicator values

```python
# In services/scanner.py, Round 2 filter section
ok = True
reasons = []

r2_rsi = filters.get("r2_rsi", 0)
if r2_rsi > 0 and ind.get("rsi", 0) < r2_rsi:
    ok = False
    reasons.append(f"RSI={ind.get('rsi', 0):.1f}<{r2_rsi}")

if filters.get("r2_macd") and not ind.get("macd_gold"):
    ok = False
    reasons.append("无MACD金叉")

if filters.get("r2_cci") and ind.get("cci", 0) <= 0:
    ok = False
    reasons.append(f"CCI={ind.get('cci', 0):.1f}≤0")

if filters.get("r2_ma20") and s["price"] <= ind.get("ma20", 0):
    ok = False
    reasons.append(f"价格{s['price']:.2f}≤MA20={ind.get('ma20', 0):.2f}")

r2_vol = filters.get("r2_vol_ratio", 0)
if r2_vol > 0 and ind.get("vol_ratio", 0) < r2_vol:
    ok = False
    reasons.append(f"量比={ind.get('vol_ratio', 0):.2f}<{r2_vol}")

r2_turn = filters.get("r2_turnover", 0)
if r2_turn > 0 and s["turnover"] < r2_turn:
    ok = False
    reasons.append(f"换手率={s['turnover']:.2f}%<{r2_turn}%")

s["pass"] = ok
results.append(s)

if ok:
    logger.info(f"    ✅ {s['name']}({s['code']}) 通过! RSI={ind.get('rsi',0):.1f} CCI={ind.get('cci',0):.1f} MACD金叉={'是' if ind.get('macd_gold') else '否'}")
else:
    logger.info(f"    ❌ {s['name']}({s['code']}) 不通过: {', '.join(reasons)}")
```

## Key Points

1. **Limit Round 1 logs to 5** - Avoid log spam when many stocks filtered
2. **Show ALL Round 2 logs** - Each stock requires API call, user wants to see each one
3. **Include actual values** - Not just pass/fail, but the calculated values for verification
4. **Use emoji indicators** - ✅ for pass, ❌ for fail for quick visual scanning
