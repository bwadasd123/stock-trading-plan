# 整数涨跌幅提醒实现

## 功能说明
- 涨跌幅达到 -10%, -9%, ..., -1%, +1%, +2%, ..., +9%, +10% 时推送
- 每个整数百分比每天只提醒一次
- 穿过整数边界时触发

## 实现逻辑

```python
# 状态文件中需要记录
state = {
    "pct_alerts": [],  # 已提醒的整数百分比列表
    "last_price": None,  # 上次检查的价格
}

# 在main()函数中
change_pct = price_data["change_pct"]  # 基于昨收的涨跌幅
yesterday = price_data["yesterday"]    # 昨收价
price = price_data["price"]            # 当前价

# 每天9:30重置状态
if now.hour == 9 and now.minute >= 25 and now.minute <= 30:
    state["pct_alerts"] = []

# 计算当前涨跌幅的整数部分
current_pct_int = int(change_pct)

# 检查是否需要提醒（-10%到+10%之间的每个整数）
if -10 <= current_pct_int <= 10 and current_pct_int != 0:
    # 检查这个整数百分比是否已经提醒过
    if current_pct_int not in state.get("pct_alerts", []):
        # 判断是否刚刚穿过这个整数（避免重复触发）
        last_price = state.get("last_price", price)
        last_change_pct = (last_price - yesterday) / yesterday * 100
        last_pct_int = int(last_change_pct)
        
        # 只在穿过整数边界时触发
        if current_pct_int != last_pct_int:
            direction = "涨" if current_pct_int > 0 else "跌"
            emoji = "📈" if current_pct_int > 0 else "📉"
            
            msg = f"{emoji} 【{direction}幅提醒】\n"
            msg += f"{STOCK_NAME} 现价 {price:.2f}（{change_pct:+.2f}%）\n"
            msg += f"今日{direction}幅达到 {current_pct_int}%\n"
            msg += "\n"
            msg += format_status(price_data)  # 完整行情
            
            send_wx(msg)
            
            # 记录已提醒的百分比
            if "pct_alerts" not in state:
                state["pct_alerts"] = []
            state["pct_alerts"].append(current_pct_int)

# 更新last_price（必须在最后）
state["last_price"] = price
```

## 注意事项

1. **int()函数行为**：
   - `int(2.7)` = 2（向下取整）
   - `int(-2.7)` = -2（向零取整）
   - 这意味着 +2.7% 触发 +2% 提醒，-2.7% 触发 -2% 提醒

2. **边界情况**：
   - 0% 不提醒（无变化）
   - 只在穿过整数边界时触发，不是每次达到都触发

3. **每天重置**：
   - 9:30 重置 pct_alerts 列表
   - 同一个百分比每天只提醒一次

4. **推送内容**：
   - 提醒消息后面跟完整的行情分析
   - 包含持仓盈亏、盘口数据、止盈止损参考
