# 监控列表变更通知 — 实现参考

## 概述

2026-07-07 新增功能：当 STOCKS 列表发生变化（新增/移除/类型变化），cronjob 下次运行时自动推送到企业微信。

## 核心函数: check_monitor_changes(state)

```python
def check_monitor_changes(state):
    """检测监控列表变更（新增/移除），首次运行不报警"""
    # 构建当前监控快照：{ts_code: (name, type)}
    current = {}
    for s in STOCKS:
        current[s["ts_code"]] = (s["name"], s["type"])
    
    snapshot = state.get("stocks_snapshot", {})
    
    # 首次运行：保存快照，不报警
    if not snapshot:
        state["stocks_snapshot"] = current
        save_state(state)
        return None
    
    # 对比差异
    added = {}    # 新增的
    removed = {}  # 移除的
    changed = {}  # type变化的（观察→持仓 或 持仓→观察）
    
    for code, (name, stype) in current.items():
        if code not in snapshot:
            added[code] = (name, stype)
        elif snapshot[code] != (name, stype):
            old_name, old_type = snapshot[code]
            if old_type != stype:
                changed[code] = (name, old_type, stype)
    
    for code, (name, stype) in snapshot.items():
        if code not in current:
            removed[code] = (name, stype)
    
    # 更新快照
    state["stocks_snapshot"] = current
    save_state(state)
    
    # 有变更才推送
    if not added and not removed and not changed:
        return None
    
    msg = "📋 【监控列表变更】\n\n"
    
    for code, (name, stype) in added.items():
        emoji = "🔴" if stype == "持仓" else "🟡"
        msg += f"  ➕ {emoji} 新增{stype}: {name} ({code})\n"
    
    for code, (name, stype) in removed.items():
        emoji = "🔴" if stype == "持仓" else "🟡"
        msg += f"  ➖ {emoji} 移除{stype}: {name} ({code})\n"
    
    for code, (name, old_type, new_type) in changed.items():
        msg += f"  🔄 {name} ({code}): {old_type} → {new_type}\n"
    
    return msg
```

## main()中的调用位置

关键：必须在 `pending_trades` 处理之后、`close_sent` 检查之前：

```python
def main():
    # ... 每日状态重置 ...
    
    # ======== 交易通知（pending_trades队列）========
    pending = state.get("pending_trades", [])
    if pending:
        for trade in pending:
            send_wx(trade["msg"])
        state["pending_trades"] = []
        save_state(state)
    
    # ======== 监控列表变更检测 ========
    change_msg = check_monitor_changes(state)
    if change_msg:
        send_wx(change_msg)
    
    # 收盘播报（之后才是交易时间检查）
    if now.hour == 15 and now.minute == 0 ...
```

## 状态文件新增字段

```json
{
  "stocks_snapshot": {
    "159599": ["芯片ETF", "持仓"],
    "600114": ["东睦股份", "持仓"],
    "513100": ["纳指ETF", "观察"],
    "000920": ["沃顿科技", "观察"],
    "002245": ["蔚蓝锂芯", "观察"],
    "002141": ["贤丰控股", "观察"],
    "002559": ["亚威股份", "观察"],
    "603928": ["兴业股份", "观察"],
    "600857": ["宁波中百", "观察"],
    "603078": ["江化微", "观察"]
  }
}
```

## 检测的三种变更类型

| 类型 | 图标 | 说明 |
|------|------|------|
| 新增 | ➕ 🟡/🔴 | ts_code不在snapshot中 |
| 移除 | ➖ 🟡/🔴 | ts_code在snapshot但不在STOCKS中 |
| 类型变化 | 🔄 | 同一code，type从"观察"→"持仓"或反之 |

## 推送消息示例

### 新增观察股
```
📋 【监控列表变更】

  ➕ 🟡 新增观察: 亚威股份 (002559)
```

### 移除 + 新增同时
```
📋 【监控列表变更】

  ➖ 🟡 移除观察: 贤丰控股 (002141)
  ➕ 🟡 新增观察: 亚威股份 (002559)
```

### 类型变化（买入/清仓）
```
📋 【监控列表变更】

  🔄 芯片ETF (159599): 观察 → 持仓
```

## 与 pending_trades 的区别

| | pending_trades | check_monitor_changes |
|------|------|------|
| 用途 | 买卖交易确认 | STOCKS列表变更通知 |
| 触发 | 手动写入状态文件 | 自动检测快照差异 |
| 消息内容 | 详细的交易记录 | 简洁的变更列表 |
| 清仓后 | 写入清仓通知 | 自动检测到 type/移除 变化 |

两者互补：pending_trades 告诉用户"发生了什么交易"，check_monitor_changes 告诉用户"监控列表变了"。
